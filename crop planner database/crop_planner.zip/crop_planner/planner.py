"""
Core computation layer. Joins crop trait data with a location's frost dates
and produces plant-by / harvest-by dates per crop, flagging crops whose
season doesn't fit.
"""

import json
from datetime import date, timedelta
from pathlib import Path

CROP_DATA_PATH = Path(__file__).parent / "crop_traits.json"


def load_crop_traits() -> list:
    with open(CROP_DATA_PATH) as f:
        data = json.load(f)
    return data["crops"]


def plan_crop(crop: dict, last_frost: date, first_frost: date | None) -> dict:
    """
    Compute plant_by and harvest_by dates for one crop given frost dates.
    """
    plant_by = last_frost + timedelta(weeks=crop["plant_offset_weeks"])
    avg_days = (crop["days_to_maturity_min"] + crop["days_to_maturity_max"]) / 2
    harvest_by = plant_by + timedelta(days=avg_days)

    fits_season = True
    if first_frost is not None:
        fits_season = harvest_by <= first_frost

    return {
        "crop": crop["crop"],
        "sun": crop["sun"],
        "water": crop["water"],
        "frost_tolerance": crop["frost_tolerance"],
        "start_method": crop["start_method"],
        "days_to_maturity_min": crop["days_to_maturity_min"],
        "days_to_maturity_max": crop["days_to_maturity_max"],
        "plant_by": plant_by.isoformat(),
        "harvest_by": harvest_by.isoformat(),
        "fits_season": fits_season,
    }


def plan_all_crops(last_frost: date, first_frost: date | None) -> list:
    crops = load_crop_traits()
    return [plan_crop(c, last_frost, first_frost) for c in crops]


def plan_single_crop(crop_name: str, last_frost: date, first_frost: date | None) -> dict:
    crops = load_crop_traits()
    match = next((c for c in crops if c["crop"] == crop_name.lower().replace(" ", "_")), None)
    if match is None:
        available = ", ".join(c["crop"] for c in crops)
        raise ValueError(f"Unknown crop '{crop_name}'. Available: {available}")
    return plan_crop(match, last_frost, first_frost)
