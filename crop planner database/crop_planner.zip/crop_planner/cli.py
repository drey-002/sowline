"""
CLI entry point.

Examples:
  python3 cli.py --zip 55401 --crop tomatoes
  python3 cli.py --zip 55401
  python3 cli.py --zone 6b --crop tomatoes
  python3 cli.py --zone 6b --crop tomatoes --last-frost 2026-04-28 --first-frost 2026-10-12
"""

import argparse
from datetime import date, datetime

from zone_lookup import fetch_zone_by_zip, estimate_frost_dates
from planner import plan_all_crops, plan_single_crop


def parse_date(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


def main():
    parser = argparse.ArgumentParser(description="Crop planting date calculator")
    parser.add_argument("--zip", help="US ZIP code (looks up zone via phzmapi.org)")
    parser.add_argument("--zone", help="USDA hardiness zone, e.g. 6b (skips ZIP lookup)")
    parser.add_argument("--crop", help="Single crop to plan (omit for all crops)")
    parser.add_argument("--last-frost", help="Override: YYYY-MM-DD")
    parser.add_argument("--first-frost", help="Override: YYYY-MM-DD")
    parser.add_argument("--year", type=int, default=date.today().year,
                         help="Year for frost estimates (default: current year)")
    args = parser.parse_args()

    zone = args.zone
    if args.zip and not zone:
        result = fetch_zone_by_zip(args.zip)
        zone = result["zone"]
        print(f"ZIP {args.zip} -> zone {zone}")

    if not zone:
        parser.error("Provide --zip or --zone")

    if args.last_frost:
        last_frost = parse_date(args.last_frost)
        first_frost = parse_date(args.first_frost) if args.first_frost else None
        print("Using supplied frost dates.")
    else:
        estimates = estimate_frost_dates(zone, args.year)
        last_frost = estimates["last_frost"]
        first_frost = estimates["first_frost"]
        if last_frost is None:
            print(f"Zone {zone}: no meaningful frost — most crops plantable year-round.")
            return
        print(f"Zone {zone} estimated frost dates: last={last_frost}, first={first_frost} "
              f"(rough national average for this zone — pass --last-frost/--first-frost "
              f"for your actual local dates)")

    if args.crop:
        result = plan_single_crop(args.crop, last_frost, first_frost)
        print_crop(result)
    else:
        for c in plan_all_crops(last_frost, first_frost):
            print_crop(c)


def print_crop(c: dict):
    flag = "" if c["fits_season"] else "  [SEASON TOO SHORT]"
    print(f"{c['crop']:15s} plant_by={c['plant_by']} harvest_by={c['harvest_by']} "
          f"sun={c['sun']:8s} water={c['water']:6s} "
          f"days={c['days_to_maturity_min']}-{c['days_to_maturity_max']}{flag}")


if __name__ == "__main__":
    main()
