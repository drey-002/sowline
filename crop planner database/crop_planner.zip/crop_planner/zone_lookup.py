"""
Zone and frost-date lookup.

Primary source: phzmapi.org/{zip}.json — a static JSON API built from the
official USDA Plant Hardiness Zone Map bulk data (github.com/waldoj/frostline).
Requires network access; not available in sandboxed environments without
egress to phzmapi.org.

Fallback: a zone -> approximate frost date table. This is a rough national
average per zone, NOT a substitute for local NOAA Climate Normals. Use
--last-frost / --first-frost on the CLI for precise dates from
https://www.weather.gov or your county extension office.
"""

import json
import urllib.request
import urllib.error
from datetime import date

PHZMAPI_URL = "https://phzmapi.org/{zip}.json"

# Rough national-average last/first frost dates by zone (month, day).
# Real dates vary by hundreds of miles within a zone due to elevation,
# coastal effects, and microclimate. Treat as a fallback only.
ZONE_FROST_ESTIMATES = {
    "3a": {"last_frost": (6, 1), "first_frost": (9, 1)},
    "3b": {"last_frost": (5, 25), "first_frost": (9, 10)},
    "4a": {"last_frost": (5, 20), "first_frost": (9, 20)},
    "4b": {"last_frost": (5, 15), "first_frost": (9, 25)},
    "5a": {"last_frost": (5, 10), "first_frost": (10, 1)},
    "5b": {"last_frost": (5, 5), "first_frost": (10, 5)},
    "6a": {"last_frost": (4, 25), "first_frost": (10, 10)},
    "6b": {"last_frost": (4, 20), "first_frost": (10, 15)},
    "7a": {"last_frost": (4, 10), "first_frost": (10, 25)},
    "7b": {"last_frost": (4, 1), "first_frost": (11, 1)},
    "8a": {"last_frost": (3, 20), "first_frost": (11, 10)},
    "8b": {"last_frost": (3, 10), "first_frost": (11, 20)},
    "9a": {"last_frost": (2, 20), "first_frost": (12, 1)},
    "9b": {"last_frost": (2, 1), "first_frost": (12, 15)},
    "10a": {"last_frost": (1, 15), "first_frost": (12, 25)},
    "10b": {"last_frost": (1, 1), "first_frost": (12, 31)},
    "11a": {"last_frost": None, "first_frost": None},
    "11b": {"last_frost": None, "first_frost": None},
}


def fetch_zone_by_zip(zip_code: str) -> dict:
    """
    Query phzmapi.org for hardiness zone data by ZIP code.
    Returns dict like {"zone": "6b", "temperature_range": "-5 to 0"} or
    raises on network/lookup failure.
    """
    url = PHZMAPI_URL.format(zip=zip_code)
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, urllib.error.HTTPError) as e:
        raise RuntimeError(
            f"Could not reach phzmapi.org for ZIP {zip_code}: {e}. "
            "Check network access or supply --zone manually."
        )


def estimate_frost_dates(zone: str, year: int) -> dict:
    """
    Fallback frost date estimate for a given zone and year.
    Returns {"last_frost": date, "first_frost": date} or None values
    for zones with no meaningful frost (11a/11b).
    """
    zone = zone.lower().strip()
    if zone not in ZONE_FROST_ESTIMATES:
        raise ValueError(f"No frost estimate available for zone '{zone}'")
    entry = ZONE_FROST_ESTIMATES[zone]
    last = date(year, *entry["last_frost"]) if entry["last_frost"] else None
    first = date(year, *entry["first_frost"]) if entry["first_frost"] else None
    return {"last_frost": last, "first_frost": first}
