# Crop Planner

Automates the pipeline discussed: ZIP → hardiness zone → frost dates → plant/harvest windows, joined against a compiled crop-trait table (sun, water, days to maturity, frost tolerance).

## Files

- `crop_traits.json` — 30 common crops, manually compiled from extension-guide ranges. Edit/extend this file to add crops.
- `zone_lookup.py` — fetches zone by ZIP from phzmapi.org (USDA data). Falls back to a rough zone→frost-date estimate table if you skip ZIP lookup.
- `planner.py` — computation layer: plant_by / harvest_by dates, season-fit check.
- `build_db.py` — merges everything into `crop_planner.db` (SQLite), the single file an AI or app queries.
- `cli.py` — command-line interface tying it together.

## Setup

```
pip install --break-system-packages requests   # not actually required, stdlib only, listed for clarity
python3 build_db.py
```

## Usage

```
python3 cli.py --zip 55401 --crop tomatoes
python3 cli.py --zone 6b
python3 cli.py --zone 6b --crop peas --last-frost 2026-04-28 --first-frost 2026-10-12
```

`--zip` requires network access to phzmapi.org (not available in this sandbox — tested here with `--zone` instead). Runs fine on a normal machine or server.

## Limitations

- Frost-date estimates by zone are rough national averages, not local data. Pass `--last-frost`/`--first-frost` from NOAA or your county extension for accuracy.
- Crop trait ranges are general; cultivar-specific numbers vary. Cross-check against your regional extension guide before relying on this for commercial planting.
- `crop_traits.json` covers 30 common crops. No API source exists for this data — extending coverage means manually adding entries from extension guides.

## Extending

Add a crop by appending an object to `crops` in `crop_traits.json`, then rerun `build_db.py`. To swap the frost-date fallback for real NOAA Climate Normals, replace `estimate_frost_dates()` in `zone_lookup.py` with a call to NOAA's CDO API (requires a free token from ncdc.noaa.gov).
