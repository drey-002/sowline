"""
Builds crop_planner.db — a single SQLite file combining:
  - crop_traits table (from crop_traits.json)
  - zone_frost_estimates table (fallback frost dates by zone)

This is the merged, structured reference an AI queries directly instead of
hitting an API and parsing extension PDFs at inference time.

Usage: python3 build_db.py
"""

import json
import sqlite3
from pathlib import Path
from zone_lookup import ZONE_FROST_ESTIMATES

DB_PATH = Path(__file__).parent / "crop_planner.db"
CROP_DATA_PATH = Path(__file__).parent / "crop_traits.json"


def build():
    if DB_PATH.exists():
        DB_PATH.unlink()

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE crop_traits (
            crop TEXT PRIMARY KEY,
            days_to_maturity_min INTEGER,
            days_to_maturity_max INTEGER,
            sun TEXT,
            water TEXT,
            frost_tolerance TEXT,
            start_method TEXT,
            plant_offset_weeks INTEGER
        )
    """)

    cur.execute("""
        CREATE TABLE zone_frost_estimates (
            zone TEXT PRIMARY KEY,
            last_frost_month INTEGER,
            last_frost_day INTEGER,
            first_frost_month INTEGER,
            first_frost_day INTEGER
        )
    """)

    with open(CROP_DATA_PATH) as f:
        crops = json.load(f)["crops"]

    for c in crops:
        cur.execute(
            """INSERT INTO crop_traits VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (c["crop"], c["days_to_maturity_min"], c["days_to_maturity_max"],
             c["sun"], c["water"], c["frost_tolerance"], c["start_method"],
             c["plant_offset_weeks"])
        )

    for zone, entry in ZONE_FROST_ESTIMATES.items():
        last = entry["last_frost"] or (None, None)
        first = entry["first_frost"] or (None, None)
        cur.execute(
            """INSERT INTO zone_frost_estimates VALUES (?, ?, ?, ?, ?)""",
            (zone, last[0], last[1], first[0], first[1])
        )

    conn.commit()
    conn.close()
    print(f"Built {DB_PATH} — {len(crops)} crops, {len(ZONE_FROST_ESTIMATES)} zones")


if __name__ == "__main__":
    build()
